//
//  FaceParserFramework.h
//  FaceParserFramework
//
//  Created by Taliyo on 29/03/2023.
//  Copyright © 2023 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FaceParserFramework.
FOUNDATION_EXPORT double FaceParserFrameworkVersionNumber;

//! Project version string for FaceParserFramework.
FOUNDATION_EXPORT const unsigned char FaceParserFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FaceParserFramework/PublicHeader.h>


